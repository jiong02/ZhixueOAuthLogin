<?php
require __DIR__ . '/common.php';
$baiduOAuth = new \Zhixue\OAuthLogin\Baidu\OAuth2;
$baiduOAuth->displayLoginAgent();