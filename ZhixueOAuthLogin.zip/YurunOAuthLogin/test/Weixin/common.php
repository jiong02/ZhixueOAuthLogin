<?php
require dirname(__DIR__) . '/common.php';
$GLOBALS['oauth_weixin'] = array(
	'appid'			=>	'',
	'appkey'		=>	'',
	'callbackUrl'	=>	'http://test.com/test/Weixin/callback.php',
);