<?php
require dirname(__DIR__) . '/common.php';
$GLOBALS['oauth_gitee'] = array(
	'appid'			=>	'',
	'appkey'		=>	'',
	'callbackUrl'	=>	'http://test.com/test/Gitee/callback.php',
);