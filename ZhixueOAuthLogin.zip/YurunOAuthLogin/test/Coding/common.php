<?php
require dirname(__DIR__) . '/common.php';
$GLOBALS['oauth_coding'] = array(
	'appid'			=>	'61c018273b979203d0320db062dece53',
	'appkey'		=>	'cd7c67ea38afbc2a2a11e1139444e4d15c2880c5',
	'callbackUrl'	=>	'http://Zhixue2.test.96007.cc/test/Coding/callback.php',
);