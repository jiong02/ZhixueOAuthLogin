<?php
require __DIR__ . '/common.php';
$codingOAuth = new \Zhixue\OAuthLogin\Coding\OAuth2;
$codingOAuth->displayLoginAgent();