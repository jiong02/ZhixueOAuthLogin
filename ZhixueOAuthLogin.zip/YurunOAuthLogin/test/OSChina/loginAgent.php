<?php
require __DIR__ . '/common.php';
$oschinaOAuth = new \Zhixue\OAuthLogin\OSChina\OAuth2;
$oschinaOAuth->displayLoginAgent();