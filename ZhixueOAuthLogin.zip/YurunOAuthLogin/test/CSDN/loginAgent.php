<?php
require __DIR__ . '/common.php';
$csdnOAuth = new \Zhixue\OAuthLogin\CSDN\OAuth2;
$csdnOAuth->displayLoginAgent();