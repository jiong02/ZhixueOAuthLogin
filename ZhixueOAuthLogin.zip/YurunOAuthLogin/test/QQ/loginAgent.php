<?php
require __DIR__ . '/common.php';
$qqOAuth = new \Zhixue\OAuthLogin\QQ\OAuth2;
$qqOAuth->displayLoginAgent();