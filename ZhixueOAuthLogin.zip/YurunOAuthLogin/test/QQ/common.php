<?php
require dirname(__DIR__) . '/common.php';
$GLOBALS['oauth_qq'] = array(
	'appid'			=>	'',
	'appkey'		=>	'',
	'callbackUrl'	=>	'http://test.com/test/QQ/callback.php',
);