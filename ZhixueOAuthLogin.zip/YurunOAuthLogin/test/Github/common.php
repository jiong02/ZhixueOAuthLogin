<?php
require dirname(__DIR__) . '/common.php';
$GLOBALS['oauth_github'] = array(
	'appid'			=>	'',
	'appkey'		=>	'',
	'callbackUrl'	=>	'http://test.com/test/Github/callback.php',
);