<?php
namespace Zhixue\OAuthLogin;

class ApiException extends \Exception
{
}